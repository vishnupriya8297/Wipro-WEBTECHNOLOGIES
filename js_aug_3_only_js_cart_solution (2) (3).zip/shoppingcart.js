class ShoppingCart{

    constructor(){
        this.items=[];
        this.discount=0;
}
//Add item to cart
addItem(item){
    const{name,price,quantity}=item;
    this.items.push({name,price,quantity});
}
//remove item from cart
removeItem(itemName){
    this.items=this.items.filter(item=>item.name!==itemName);
}
//Caluculate total price
calculateTotalPrice(){
    return this.items.reduce((total,item)=>total+item.price*item.quantity,0);

}
//Apply discount code
applyDiscountcode(code){
    const discounts={
        SAVE10:0.10,
        SAVE20:0.20,
        SAVE30:0.30
    };
    this.discount=discounts[code]||0;
}
//Calculate tax
calculateTax(taxRate){
    const total=this.calculateTotalPrice();
    return total*taxRate;
}
//Checkout
checkout(taxRate){
    const total=this.calculateTotalPrice();
    const tax=total*taxRate;
    const discountAmount=total*this.discount;
    const finalAmount=total+tax-discountAmount;
    //clear cart after checkout
    this.items=[];
    this.discount=0;
    return finalAmount;
}
}
module.exports=ShoppingCart;