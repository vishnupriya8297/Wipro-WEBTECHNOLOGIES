//to test my code i am creating a test file
const InventoryManager = require('../inventoryManager');
describe("Inventory Managment Service",()=>{
    test("Add product and retrive it by ID",()=>{
        const inventory=new InventoryManager();
        inventory.addProduct({productID:1,name:"Laptop",category:"Electronics",price:50000,stock:10});
        const product=inventory.getProductById(1);
        expect(product.name).toBe("Laptop");
        expect(product.price).toBe(50000);
    });
})