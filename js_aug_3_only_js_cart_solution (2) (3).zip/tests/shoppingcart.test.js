//to test my code i am creating a test file
const shoppingCart = require('../shoppingcart');
test("add item and calculate total",()=>{
    const cart=new shoppingCart();
    cart.addItem({name:"Book",price:100,quantity:2});
    expect(cart.calculateTotalPrice()).toBe(200);
});
test("add multiple items and calculate total",()=>{
    const cart=new shoppingCart();
    cart.addItem({name:"Book",price:100,quantity:2});
    cart.addItem({name:"Pen",price:10,quantity:5});
    expect(cart.calculateTotalPrice()).toBe(250);
});
test("remove item and calculate total",()=>{
    const cart=new shoppingCart();
    cart.addItem({name:"Book",price:100,quantity:2});
    cart.addItem({name:"Pen",price:10,quantity:5});
    cart.removeItem("Book");
    expect(cart.calculateTotalPrice()).toBe(50);
});