class InventoryManager{
    constructor(){
        this.products=[];
    }
    addProduct(product){
        const exists=this.products.find(p=>p.productID===product.productID);
        if(exists){
            throw new Error("product already exists");
        }
        this.products.push(product);
    }
    getProductById(productID){
        return this.products.find(p=>p.productID===productID)||null;
    }
    updateProduct(productID,updatedFields){
        const product=this.products.find(p=>p.productID===productID);
        if(!product){
            throw new Error("Product not found");

        }
        Object.assign(product,updatedFields);
    }
    deleteProduct(productID){
        const index=this.products.findIndex(p=>p.productID===productID);
        if(index===-1){
            throw new Error("Product not found");
        }
        this.products.splice(index,1);
    }
    listAllProducts(){
        return this.products;
    }
}
module.exports=InventoryManager;